function [projection, IC, W] = assemblyActivations(TS, nAssemblies)
%	ASSEMBLYACTIVATIONS calculates the significantly different assembly
% entropies in two conditions (may be extended to more)
% 

[projection, IC, W]=fastica25(TS,'numOfIC',nAssemblies,'verbose','off');