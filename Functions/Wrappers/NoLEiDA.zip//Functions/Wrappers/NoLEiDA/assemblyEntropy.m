function [entro] = assemblyEntropy(projection, nAssemblies, N, T, co)
%	ASSEMBLYENTROPY calculates the Shannon entropy of the assemblies based
% on assembly activation time courses.
%	

% Preallocate arrays
entro2 = nan(nAssemblies, 1);
entro.ass = nan(max(N.subjects), N.condition, nAssemblies);
entro.sub = nan(max(N.subjects), N.condition);

% Loop over tasks
for c = 1:N.condition
	% Loop over subjects
	for s = 1:N.subjects(c)
		
        disp(['Analyzing condition ', num2str(c), ' and subject ', num2str(s), '.']);
        
		% Select the time points representing this subject and task
		T = (T(c,:)==s)';
		
		% Extract entropy of BOLD timeseries assembly activations
		for ass = 1:nAssemblies
            disp(['Analyzing assembly ', num2str(ass), '.']);
			entro2(ass) = HShannon_kNN_k_estimation(squeeze(projection(ass, T)), co);
			entro.ass(s,c,ass) = entro2(ass);
		end
        entro.sub(s,c) = sum(entro2);
	end
end

end

