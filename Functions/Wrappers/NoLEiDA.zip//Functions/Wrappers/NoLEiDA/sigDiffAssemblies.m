function [ICsig, pval, h] = sigDiffAssemblies(entro, IC, nAssemblies, N, pval)
%	SIGDIFFASSEMBLIES calculates the significantly different assembly
% entropies in two conditions (may be extended to more)
% 

%% Compare entropies for each condition

% Run rank-sum comparisons of timeseries entropies between tasks
a = entro.sub(1:N.subjects(1), 1)';
b = entro.sub(1:N.subjects(2), 2)';
pval.entro = ranksum(a, b);
disp(pval.entro);

% Preallocate assemblywise entropy
pval.assembly = nan(nAssemblies, 1);

% Compare assemblywise entropies
for ass = 1:nAssemblies
    a = squeeze(entro.ass(1:N.subjects(1), 1, ass))';
    b = squeeze(entro.ass(1:N.subjects(2), 2, ass))';
    pval.assembly(ass) = ranksum(a,b);
end

% Detect significantly different assemblies (multiple-test correction)
h.I = FDR_benjHoch(pval.assembly, pval.target);

% Convert connectivity vectors of significantly different components to connectivity matrices
ICsig = IC(:,h.I);			% Extract significantly different components
numcomp = size(ICsig, 2);	% find number of significantly different components
numind = size(IC, 1);		% find number of elements in connectivity matrix
ICsig = nan(N.ROI, N.ROI, numcomp);
for ass = 1:numcomp
	for i = 1:numind
		[ii, jj] = ind2sub([N.ROI N.ROI], Isubdiag(i));
		ICsig(ii,jj,ass) = ICsig(i,ass);
		ICsig(jj,ii,ass) = ICsig(i,ass);
	end
end

% Record p-value of significantly different assemblies
h.p = nan(nAssemblies, 1);
for ass = 1:nAssemblies
    if ismember(ass, h.I)
        h.p(ass) = max(pval.assembly);
    else
        h.p(ass) = 0;
    end
end

end

