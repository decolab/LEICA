mex SW_kappa.cpp;
mex SW_sigma.cpp;